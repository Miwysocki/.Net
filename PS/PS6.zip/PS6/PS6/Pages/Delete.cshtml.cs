﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;
using System.Text;

namespace PS6
{
    public class DeleteModel : PageModel
    {
        [BindProperty(SupportsGet = true)]
        public int id { get; set; }

        private readonly ILogger<DeleteModel> _logger;
        public IConfiguration _configuration { get; }
        public DeleteModel(IConfiguration configuration, ILogger<DeleteModel> logger)
        {
            _logger = logger;
            _configuration = configuration;
        }
        public IActionResult OnGet()
        {
            string myCompanyDBcs = _configuration.GetConnectionString("myCompanyDB");
            SqlConnection con = new SqlConnection(myCompanyDBcs);
            string sql = "DELETE from dbo.Product WHERE Id = @id ";
            SqlCommand cmd = new SqlCommand(sql, con);
            con.Open();


            


            using (con)
            using (cmd)
            {
                // add parameters and their values
                cmd.Parameters.Add("@id", System.Data.SqlDbType.NVarChar, 100).Value = id;

                cmd.ExecuteNonQuery();
                con.Close();
                return RedirectToPage("Index");
            }
        }
    }
}