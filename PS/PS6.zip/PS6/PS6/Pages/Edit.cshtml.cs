﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;
using System.Text;


namespace PS6
{
    public class EditModel : PageModel
    {
        [BindProperty(SupportsGet = true)]
        public string name { get; set; }
        [BindProperty(SupportsGet = true)]
        public float price { get; set; }
        [BindProperty(SupportsGet = true)]
        public int id { get; set; }
        [BindProperty(SupportsGet = true)]
        public string details { get; set; }


        private readonly ILogger<EditModel> _logger;
        public IConfiguration _configuration { get; }
        public EditModel(IConfiguration configuration, ILogger<EditModel> logger)
        {
            _logger = logger;
            _configuration = configuration;
        }
        public string lblInfoText;
        public IActionResult OnPost()
        {
            string myCompanyDBcs = _configuration.GetConnectionString("myCompanyDB");
            SqlConnection con = new SqlConnection(myCompanyDBcs);
            string sql = "UPDATE dbo.Product SET name = @na, price = @pr WHERE Id = @id";
            SqlCommand cmd = new SqlCommand(sql, con);
            con.Open();



            using (con)
            using (cmd)
            {
                // add parameters and their values
                cmd.Parameters.Add("@id", System.Data.SqlDbType.NVarChar, 100).Value = id;
                cmd.Parameters.Add("@na", System.Data.SqlDbType.NVarChar, 100).Value = name;
                cmd.Parameters.Add("@pr", System.Data.SqlDbType.Money, 100).Value = price;

                // open connection, execute command and close connection
                cmd.ExecuteNonQuery();
                con.Close();
                return RedirectToPage("Index");
            }
        }
    }
}