﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace PS6.Models
{
    public class Product 
    {
        [Display(Name = "Id")]
        public int i { get; set; }
        [Display(Name = "Nazwa")]
        public string n { get; set; }
        [Display(Name = "Cena")]
        public decimal p { get; set; }

        public Product(int i, string n, decimal p)
        {
            this.id = i;
            this.name = n;
            this.price = p;
        }

        public int id { get; set; }
        public string name { get; set; }
        public decimal price { get; set; }
    }
}
