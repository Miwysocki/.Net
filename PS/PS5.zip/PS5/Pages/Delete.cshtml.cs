﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using PS5.DAL;
using PS5.Models;

namespace PS5
{
    public class DeleteModel : MyPageModel
    {
        [BindProperty(SupportsGet = true)]
        public Product deleteProduct { get; set; }

        [BindProperty(SupportsGet = true)]
        public int id { get; set; }
        
        [BindProperty(SupportsGet = true)]
        public string name { get; set; }
        public RedirectToPageResult OnGet()
        {
            LoadDB();
            deleteProduct.id = id;
            productDB.Delete(deleteProduct);
            SaveDB();
            return RedirectToPage("List");
        }
        public RedirectToPageResult OnPostDelete()
        {
            LoadDB();
            deleteProduct.id = id;
            productDB.Delete(deleteProduct);
            SaveDB();
            return RedirectToPage("List");
        }
        public IActionResult OnPost()
        {
            
            return RedirectToPage("List");
        }
    }
}
