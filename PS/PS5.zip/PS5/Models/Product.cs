﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace PS5.Models

{
    public class Product
    {
        [Required]
        [Display(Name = "Id")]
        public int id { get; set; }
        [Required]
        [Display(Name = "Nazwa")]
        public string name { get; set; }
        [Required]
        [Range(0, 999999.99)]
        [Display(Name = "Cena")]
        public decimal price { get; set; }
        [Display(Name = "Detale")]
        public string details { get; set; }
        public static List<Product> GetProducts()
        {
            Product pilka = new Product
            {
                id = 1,
                name = "Piłka nożna",
                price = 25.30M,
                details = " A ball is a round object with various uses. It is used in ball games, where the play of the game follows the state of the ball as it is hit, kicked or thrown by players."
            };
            Product narty = new Product { id = 2, name = "Narty", price = 150.39M ,details = " ślizgają się po powierzchni śniegu ponieważ ciepło wytworzone tarciem nart powoduje, że topi się śnieg znajdujący się bezpośrednio pod nartą"};
            Product rakieta = new Product { id = 3, name = "Rakieta ", price = 111.10M , details = " pojazd latający lub pocisk, napędzany silnikiem rakietowym."};
            return new List<Product> { pilka, narty, rakieta };
        }
    }
}
