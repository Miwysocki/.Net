﻿using Newtonsoft.Json;
using PS5.Models;
using System;
using System.Collections.Generic;
namespace PS5.DAL
{
    public class ProductDB
    {
        private List<Product> products;
        public void Load(string jsonProducts)
        {
            if (jsonProducts == null)
            {
                products = Product.GetProducts();
            }
            else
            {
                products = JsonConvert.DeserializeObject<List<Product>>(jsonProducts);
            }
        }

        private int GetNextId()
        {
            int lastID = products[products.Count - 1].id;
            int newID = ++lastID;
            return newID;
        }
        public void Create(Product p)
        {
            p.id = GetNextId();
            products.Add(p);
        }

        public void Edit(Product p)
        {
            foreach (Product item in products)
            {
                if (item.id == p.id)
                {
                    item.name = p.name;
                    item.price = p.price;
                    item.details = p.details;
                }
            }
        }
        
        public void Delete(Product p)
        {
            foreach (Product item in products)
            {
                if (item.id == p.id)
                {
                    products.Remove(item);
                    break ;
                }
            }
        }
        public string Save()
        {

            return JsonConvert.SerializeObject(products);
        }
        public List<Product> List()
        {
            return products;
        }
    }
}
