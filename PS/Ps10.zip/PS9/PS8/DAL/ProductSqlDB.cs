﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;
using System.Text;
using System.Data;
using PS9.Models;

namespace PS9.DAL
{
    public class ProductSqlDB : IProductDB
    {
        private readonly ILogger<ProductSqlDB> _logger;
        public IConfiguration _configuration { get; }
        public ProductSqlDB(IConfiguration configuration, ILogger<ProductSqlDB> logger)
        {
            _logger = logger;
            _configuration = configuration;
        }
        public int Add(Product _product)
        {
            decimal price = _product.price;
            string name = _product.name;
            string myCompanyDB_connection_string =
           _configuration.GetConnectionString("myCompanyDB");
            SqlConnection con = new SqlConnection(myCompanyDB_connection_string);
            SqlCommand cmd = new SqlCommand("sp_productAdd", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter name_SqlParam = new SqlParameter("@name", SqlDbType.VarChar,
           50);
            name_SqlParam.Value = name;
            cmd.Parameters.Add(name_SqlParam);
            SqlParameter price_SqlParam = new SqlParameter("@price", SqlDbType.Money);
            price_SqlParam.Value = price;
            cmd.Parameters.Add(price_SqlParam);
            SqlParameter productID_SqlParam = new SqlParameter("@productID",
           SqlDbType.Int);
            productID_SqlParam.Direction = ParameterDirection.Output;
            cmd.Parameters.Add(productID_SqlParam);
            con.Open();
            int numAff = cmd.ExecuteNonQuery();
            con.Close();
            return 0;
        }

        public int Delete(int _id)
        {
            string myCompanyDB_connection_string =
           _configuration.GetConnectionString("myCompanyDB");
            SqlConnection con = new SqlConnection(myCompanyDB_connection_string);
            SqlCommand cmd = new SqlCommand("sp_productDelete", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter productID_SqlParam = new SqlParameter("@productID",
           SqlDbType.Int);
            productID_SqlParam.Value = _id;
            cmd.Parameters.Add(productID_SqlParam);
            con.Open();
            int numAff = cmd.ExecuteNonQuery();
            con.Close();
            return 0;
        }

        public Product Get(int _id)
        {
            string myCompanyDB_connection_string =
           _configuration.GetConnectionString("myCompanyDB");
            SqlConnection con = new SqlConnection(myCompanyDB_connection_string);
            SqlCommand cmd = new SqlCommand("sp_getproduct", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter productID_SqlParam = new SqlParameter("@productID",
           SqlDbType.Int);
            productID_SqlParam.Value = _id;
            cmd.Parameters.Add(productID_SqlParam);
            con.Open();
            int numAff = cmd.ExecuteNonQuery();
            SqlDataReader reader = cmd.ExecuteReader();
            Product p = new Product();
             p.id= int.Parse(reader["Id"].ToString());
             p.name= reader["name"].ToString();
            p.price = decimal.Parse(reader["price"].ToString());
            con.Close();
            return p;
        }

        public List<Product> List()
        {
            string myCompanyDB_connection_string =
           _configuration.GetConnectionString("myCompanyDB");
            SqlConnection con = new SqlConnection(myCompanyDB_connection_string);
            SqlCommand cmd = new SqlCommand("sp_getall", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            int numAff = cmd.ExecuteNonQuery();
            SqlDataReader reader = cmd.ExecuteReader();
            Product p = new Product();
            List<Product> list = new List<Product>();
            while (reader.Read())
                { 
                p.id = int.Parse(reader["Id"].ToString());
                p.name = reader["name"].ToString();
                p.price = decimal.Parse(reader["price"].ToString());
                list.Add(p);
                 }
            con.Close();
            return list;
        }

        public int Update(Product _product)
        {
            decimal price = _product.price;
            string name = _product.name;
            int id = _product.id;
            string myCompanyDB_connection_string =
       _configuration.GetConnectionString("myCompanyDB");
            SqlConnection con = new SqlConnection(myCompanyDB_connection_string);
            SqlCommand cmd = new SqlCommand("sp_productEdit", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter name_SqlParam = new SqlParameter("@name", SqlDbType.VarChar,
           50);
            name_SqlParam.Value = name;
            cmd.Parameters.Add(name_SqlParam);
            SqlParameter price_SqlParam = new SqlParameter("@price", SqlDbType.Money);
            price_SqlParam.Value = price;
            cmd.Parameters.Add(price_SqlParam);
            SqlParameter productID_SqlParam = new SqlParameter("@productID",
           SqlDbType.Int);
            productID_SqlParam.Value = id;
            cmd.Parameters.Add(productID_SqlParam);
            con.Open();
            int numAff = cmd.ExecuteNonQuery();
            con.Close();
            int productID = (int)cmd.Parameters["@productID"].Value;
            return 0;
        }
    }
}
