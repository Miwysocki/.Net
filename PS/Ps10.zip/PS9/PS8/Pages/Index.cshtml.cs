﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Xml;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using PS9.DAL;
using PS9.Models;

namespace PS9.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;

        public List<Product> productList;
        IProductDB productDB;
        public IndexModel(IProductDB _productDB)
        {
            productDB = _productDB;
        }
        public void OnGet()
        {
            productList = productDB.List();

        }

    }
}
