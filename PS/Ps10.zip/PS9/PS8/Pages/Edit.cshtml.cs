﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using PS9.DAL;
using PS9.Models;

namespace PS9
{
    public class EditModel : PageModel
    {
        [BindProperty(SupportsGet = true)]
        public string name { get; set; }
        [BindProperty(SupportsGet = true)]
        public decimal price { get; set; }
        public static int id;
        IProductDB productDB;
        public void OnGet(int _id)
        {
            id = _id;
        }
        public EditModel(IProductDB _productDB)
        {
            productDB = _productDB;
        }
        public RedirectToPageResult OnPost()
        {
            Product p = new Product();
            p.name = name;
            p.price = price;
            p.id = id;
            productDB.Update(p);
            return RedirectToPage("Index");
        }

    }
}