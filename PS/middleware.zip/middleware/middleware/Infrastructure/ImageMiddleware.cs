﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using System.Drawing;
using System.IO;
using System.Drawing.Imaging;

namespace middleware.Infrastructure
{
    // You may need to install the Microsoft.AspNetCore.Http.Abstractions package into your project
    public class ImageMiddleware
    {
        private readonly RequestDelegate _next;

        public ImageMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public Task Invoke(HttpContext httpContext)
        {
            string url = httpContext.Request.Path;
            if (url.ToLower().Contains(".jpg"))
            {
               try { 
                Image img = Image.FromFile("./img/" + url);
                MemoryStream stream = new MemoryStream();
                httpContext.Response.ContentType = "image/jpeg";

                    using (img )
                    {
                        using (var graphic = Graphics.FromImage(img))
                        {
                            var font = new Font(FontFamily.GenericSansSerif, 80, FontStyle.Bold, GraphicsUnit.Pixel);
                            var color = Color.Red;
                            var brush = new SolidBrush(color);
                            var point = new Point(img.Width-1500, img.Height-180);
                            graphic.DrawString("Michał Wysocki", font, brush, point);
                            img.Save(stream, ImageFormat.Png);
                        }
                    }

                    return httpContext.Response.Body.WriteAsync(stream.ToArray(), 0,
                (int)stream.Length);
                }
                catch (FileNotFoundException e)
                {
                    Image img = Image.FromFile("./img/error.jpg" );
                    MemoryStream stream = new MemoryStream();
                    img.Save(stream, System.Drawing.Imaging.ImageFormat.Png);
                    httpContext.Response.ContentType = "image/jpeg";
                    return httpContext.Response.Body.WriteAsync(stream.ToArray(), 0,
                    (int)stream.Length);
                }
            }
            return _next(httpContext);
        }

    }

    // Extension method used to add the middleware to the HTTP request pipeline.
    public static class ImageMiddlewareExtensions
    {
        public static IApplicationBuilder UseImageMiddleware(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<ImageMiddleware>();
        }
    }
}
