﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PS7.Models
{
    public class Category
    {

        public Category(int i, string sn, string ln)
        {
            this.id = i;
            this.shortName =sn;
            this.longName = ln;
        }
        public Category() { }
        public int id { get; set; }
        public string shortName { get; set; }
        public string longName { get; set; }
    }
}
