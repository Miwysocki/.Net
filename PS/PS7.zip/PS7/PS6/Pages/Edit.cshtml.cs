﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;
using System.Text;
using System.Data;
using PS7.Models;

namespace PS7
{
    public class EditModel : PageModel
    {
        [BindProperty(SupportsGet = true)]
        public string name { get; set; }
        [BindProperty(SupportsGet = true)]
        public float price { get; set; }
        [BindProperty(SupportsGet = true)]
        public int id { get; set; }
        [BindProperty(SupportsGet = true)]
        public string details { get; set; }
        [BindProperty(SupportsGet = true)]
        public string category { get; set; }
        public List<Category> categoryList = new List<Category>();
        public static List<Category> catList { get; set; }
        [BindProperty(SupportsGet = true)]
        public string chosenCategory { get; set; }


        private readonly ILogger<EditModel> _logger;
        public IConfiguration _configuration { get; }
        public EditModel(IConfiguration configuration, ILogger<EditModel> logger)
        {
            _logger = logger;
            _configuration = configuration;
        }
        public string lblInfoText;
        public IActionResult OnPost()
        {
            foreach (Category cat in catList)
            {
                if (cat.shortName.Length != chosenCategory.Length)
                {
                    int MaxLength = chosenCategory.Length;
                    cat.shortName = cat.shortName.Substring(0, MaxLength);
                }
                if (String.Equals(cat.shortName, chosenCategory))
                {
                    category = cat.longName;
                    break;
                }
            }
                string myCompanyDB_connection_string =
           _configuration.GetConnectionString("myCompanyDB");
            SqlConnection con = new SqlConnection(myCompanyDB_connection_string);
            SqlCommand cmd = new SqlCommand("sp_productEdit", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter name_SqlParam = new SqlParameter("@name", SqlDbType.VarChar,
           50);
            name_SqlParam.Value = name;
            cmd.Parameters.Add(name_SqlParam);
            SqlParameter price_SqlParam = new SqlParameter("@price", SqlDbType.Money);
            price_SqlParam.Value = price;
            cmd.Parameters.Add(price_SqlParam);
            SqlParameter productID_SqlParam = new SqlParameter("@productID",
           SqlDbType.Int);
            //productID_SqlParam.Direction = ParameterDirection.Output;
            productID_SqlParam.Value = id;
            cmd.Parameters.Add(productID_SqlParam);
            SqlParameter category_SqlParam = new SqlParameter("@category", SqlDbType.VarChar, 50);
            category_SqlParam.Value = category;
            cmd.Parameters.Add(category_SqlParam);
            con.Open();
            int numAff = cmd.ExecuteNonQuery();
            con.Close();
            lblInfoText += String.Format("Inserted <b>{0}</b> record(s)<br />", numAff);
            int productID = (int)cmd.Parameters["@productID"].Value;
            lblInfoText += "New ID: " + productID.ToString();
            return RedirectToPage("Index");
        }
        public void OnGet()
        {
            string myCompanyDBcs = _configuration.GetConnectionString("myCompanyDB");
            SqlConnection con = new SqlConnection(myCompanyDBcs);
            string sql = "SELECT * FROM Category";
            SqlCommand cmd = new SqlCommand(sql, con);
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                string i = reader["ID"].ToString();
                string sn = reader.GetString(1);
                string ln = reader.GetString(2);
                Category pro = new Category(int.Parse(i), sn, ln);
                categoryList.Add(pro);
            }
            con.Close();
            catList = categoryList;
        }
        }
    }
