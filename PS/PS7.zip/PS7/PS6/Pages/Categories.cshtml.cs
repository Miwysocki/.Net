﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using PS7.Models;

namespace PS7
{
    public class CategoriesModel : PageModel
    {

        private readonly ILogger<CategoriesModel> _logger;
        public IConfiguration _configuration { get; }

        private object reader;
        public CategoriesModel(IConfiguration configuration, ILogger<CategoriesModel> logger)
        {
            _logger = logger;
            _configuration = configuration;
        }

        public  List<Category> categoryList = new List<Category>();
        public void OnGet()
        {
            string myCompanyDBcs = _configuration.GetConnectionString("myCompanyDB");
            SqlConnection con = new SqlConnection(myCompanyDBcs);
            string sql = "SELECT * FROM Category";
            SqlCommand cmd = new SqlCommand(sql, con);
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                string i = reader["ID"].ToString();
                string sn = reader.GetString(1);
                string ln = reader.GetString(2);

                Category pro = new Category(int.Parse(i), sn, ln);
                categoryList.Add(pro);
            }
        }
        public RedirectToPageResult OnPostDelete(int id)
        {
            string myCompanyDB_connection_string =
          _configuration.GetConnectionString("myCompanyDB");
            SqlConnection con = new SqlConnection(myCompanyDB_connection_string);
            SqlCommand cmd = new SqlCommand("sp_categoryDelete", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter productID_SqlParam = new SqlParameter("@ID",
           SqlDbType.Int);
            //productID_SqlParam.Direction = ParameterDirection.Output;
            productID_SqlParam.Value = id;
            cmd.Parameters.Add(productID_SqlParam);
            con.Open();
            int numAff = cmd.ExecuteNonQuery();
            con.Close();
            return RedirectToPage("Index");
        }
    }
}