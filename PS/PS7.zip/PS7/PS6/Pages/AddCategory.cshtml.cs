﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;
using System.Text;
using System.Data;
namespace PS7
{
    public class AddCategoryModel : PageModel
    {
        [BindProperty(SupportsGet = true)]
        public string shortName { get; set; }
        [BindProperty(SupportsGet = true)]
        public string longtName { get; set; }
        [BindProperty(SupportsGet = true)]
        public int id { get; set; }

        private readonly ILogger<AddCategoryModel> _logger;
        public IConfiguration _configuration { get; }
        public AddCategoryModel(IConfiguration configuration, ILogger<AddCategoryModel> logger)
        {
            _logger = logger;
            _configuration = configuration;
        }
        public IActionResult OnPost()
        {

            string myCompanyDB_connection_string =
           _configuration.GetConnectionString("myCompanyDB");
            SqlConnection con = new SqlConnection(myCompanyDB_connection_string);
            SqlCommand cmd = new SqlCommand("sp_categoryAdd", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter name_SqlParam = new SqlParameter("@shortName", SqlDbType.VarChar,
           50);
            name_SqlParam.Value = shortName;
            cmd.Parameters.Add(name_SqlParam);
            SqlParameter price_SqlParam = new SqlParameter("@longName", SqlDbType.VarChar);
            price_SqlParam.Value = longtName;
            cmd.Parameters.Add(price_SqlParam);
            SqlParameter productID_SqlParam = new SqlParameter("@ID",
           SqlDbType.Int);
            productID_SqlParam.Direction = ParameterDirection.Output;
            cmd.Parameters.Add(productID_SqlParam);
            con.Open();
            int numAff = cmd.ExecuteNonQuery();
            con.Close();
            return RedirectToPage("Categories");
        }
    }
}