﻿using PS8.Models;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml;


namespace PS8.DAL
{
    public class ProductXmlDB : IProductDB
    {
        XmlDocument doc = new XmlDocument();
        string xmlDB_path;

        public ProductXmlDB(IConfiguration _configuration)
        {
            xmlDB_path = _configuration.GetValue<string>("AppSettings:XmlDB_path");
             LoadDB();
        }
        public void LoadDB()
        {
            doc.Load("DATA/store.xml");
        }
        private void SaveDB()
        {
            doc.Save("DATA/store.xml");
        }
        public List<Product> List()
        {
            List<Product> productList = new List<Product>();
            XmlNodeList productXmlNodeList = doc.SelectNodes("/store/product");

            foreach (XmlNode productXmlNode in productXmlNodeList)
            {
                productList.Add(XmlNodeProduct2Product(productXmlNode));
            }
            return productList;
        }
        
        public Product Get(int _id)
        {
            XmlNodeList productXmlNodeList = doc.SelectNodes("/store/product");
            foreach (XmlNode productXmlNode in productXmlNodeList)
            {
                if( _id == int.Parse(productXmlNode.Attributes["id"].Value))
                {
                    return XmlNodeProduct2Product(productXmlNode);
                }
            }   
            Product pa = null;
            return  pa;

        }
        
        public int Update(Product _product)
        {
            XmlNode node = XmlNodeProductGet(_product.id);
            node["name"].InnerText = _product.name;
            node["price"].InnerText = _product.price.ToString();
            SaveDB();
            return 0; 
        }
        public int Delete(int _id)
        {
            XmlNode node = XmlNodeProductGet(_id);
            node.ParentNode.RemoveChild(node);
            SaveDB();
            return 0; 
        }
        public int Add(Product _product)
        {
            List<Product> productList = new List<Product>();
            XmlNodeList productXmlNodeList = doc.SelectNodes("/store/product");

            //getting the biggest id
            int new_id = 0;
            foreach (XmlNode productXmlNode in productXmlNodeList)
            {
              if ( new_id < int.Parse(productXmlNode.Attributes["id"].Value) )
                {
                    new_id++;
                }
            }
            new_id += 1;

            XmlNode node = XmlNodeProductGet(new_id-1);


            XmlElement inne = doc.CreateElement("product");
            inne.SetAttribute("id", new_id.ToString());
            XmlElement name = doc.CreateElement("name");
            name.InnerText = _product.name;
            XmlElement price = doc.CreateElement("price");
            price.InnerText = _product.price.ToString();

            inne.AppendChild(name);
            inne.AppendChild(price);

            XmlNode root = node.ParentNode;
            root.AppendChild(inne);
   

            SaveDB();
            return 0;
        }
        private Product XmlNodeProduct2Product(XmlNode node)
        {
            Product p = new Product();
            p.id = int.Parse(node.Attributes["id"].Value);
            p.name = node["name"].InnerText;
            p.price = decimal.Parse(node["price"].InnerText);
            return p;
        }
        private XmlNode XmlNodeProductGet(int _id)
        {
            XmlNode node = null;
            XmlNodeList list = doc.SelectNodes("/store/product[@id=" + _id.ToString() +
           "]");
            node = list[0];
            return node;
        }

    }

}
