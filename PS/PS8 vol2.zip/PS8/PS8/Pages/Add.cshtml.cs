﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using PS8.DAL;
using PS8.Models;

namespace PS8
{
    public class AddModel : PageModel
    {
        IProductDB productDB;
        public AddModel(IProductDB _productDB)
        {
            productDB = _productDB;
        }
        [BindProperty(SupportsGet = true)]
        public string name { get; set; }
        [BindProperty(SupportsGet = true)]
        public decimal price { get; set; }
        public void OnGet()
        {

        }
        public RedirectToPageResult OnPost()
        {
            Product p = new Product();
            p.name = name;
            p.price = price;

            productDB.Add(p);
            return RedirectToPage("Index");

        }
    }
}