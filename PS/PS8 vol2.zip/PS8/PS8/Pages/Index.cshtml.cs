﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using PS8.DAL;
using PS8.Models;

namespace PS8.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;


        public List<Product> productList;
        IProductDB productDB;
        public IndexModel(IProductDB _productDB)
        {
            productDB = _productDB;
        }
        public void OnGet()
        {
            productList = productDB.List();
        }


        /*
        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }
        

        public List<Product> productList = new List<Product>();
         public void OnGet()
        {
            XmlDocument doc = new XmlDocument();
            doc.Load("DATA/store.xml");
            XmlNodeList xnList = doc.SelectNodes("/store/product");

            foreach (XmlNode xn in xnList)
            {
                productList.Add(XmlNode2Product(xn));
            }
        }
         
        private Product XmlNode2Product(XmlNode node)
        {
            Product p = new Product();
            p.id = int.Parse(node.Attributes["id"].Value);
            p.name = node["name"].InnerText;
            p.price = decimal.Parse(node["price"].InnerText);
            return p;
        }
        */
    }
}
