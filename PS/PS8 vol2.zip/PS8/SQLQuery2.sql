﻿DROP PROCEDURE sp_categoryAdd
GO
CREATE PROCEDURE [dbo].[sp_categoryAdd]
@shortName VARCHAR (50),
@longName VARCHAR (50),
@ID int OUTPUT
AS
INSERT INTO Category(shortName, longName) VALUES (@shortName, @longName)
SET @ID = @@IDENTITY
GO
DROP PROCEDURE sp_categoryEdit
go
CREATE PROCEDURE [dbo].[sp_categoryEdit]
@shortName VARCHAR (50),
@longName VARCHAR (50),
@ID int 
AS
UPDATE dbo.Category SET shortName = @shortName, longName = @longName WHERE ID = @ID
go
DROP PROCEDURE sp_categoryDelete
go
CREATE PROCEDURE [dbo].[sp_categoryDelete]
@ID int 
AS
DELETE from dbo.Category WHERE ID = @ID
GO
DROP PROCEDURE sp_productAdd
GO
CREATE PROCEDURE [dbo].[sp_productAdd]
@name VARCHAR (50),
@category VARCHAR (50),
@price MONEY,
@productID int OUTPUT
AS
INSERT INTO dbo.Product (name, price,category) VALUES (@name, @price,@category)
SET @productID = @@IDENTITY
GO
DROP PROCEDURE sp_productEdit
go
CREATE PROCEDURE [dbo].[sp_productEdit]
@name VARCHAR (50),
@price MONEY,
@productID int ,
@category VARCHAR (50)
AS
UPDATE dbo.Product SET name = @name, price = @price, category = @category WHERE Id = @productID
go
DROP PROCEDURE sp_productDelete
go
CREATE PROCEDURE [dbo].[sp_productDelete]
@productID int 
AS
DELETE from dbo.Product WHERE Id = @productID
go
CREATE PROCEDURE [dbo].[sp_getproduct]
@productID int
AS
SELECT Product from dbo.Product WHERE Id = @productID
go
CREATE PROCEDURE [dbo].[sp_getall]
AS
SELECT * from dbo.Product 
